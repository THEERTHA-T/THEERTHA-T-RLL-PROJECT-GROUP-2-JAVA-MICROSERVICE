package com.ipm.api.customerPolicyApply;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ipm.api.TodysDate;

import lombok.Data;

@Entity
@Table(name = "Customer_Apply_Policies")
public class CustomerApplyPolicy {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="User_Id")
	private Long appid;
	
	@Column(name="Customer_Name")
	private String customername;
	
	@Column(name="Customer_Mail")
	private String customeremail;
	
	@Column(name="Policy_Price")
	private String policyPrice;
	
	@Column(name="Policy_Category")
	private String policyCatagory;

	@Column(name="Policy_Name")
	private String policyName;
	
	@Column(name="Policy_Status")
	private String status="Pending";
	
	@Column(name="Policy_Date")
	private String policyapplydate = TodysDate.todayDate();

	public CustomerApplyPolicy() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerApplyPolicy(Long appid, String customername, String customeremail, String policyPrice,
			String policyCatagory, String policyName, String status, String policyapplydate) {
		super();
		this.appid = appid;
		this.customername = customername;
		this.customeremail = customeremail;
		this.policyPrice = policyPrice;
		this.policyCatagory = policyCatagory;
		this.policyName = policyName;
		this.status = status;
		this.policyapplydate = policyapplydate;
	}

	public Long getAppid() {
		return appid;
	}

	public void setAppid(Long appid) {
		this.appid = appid;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getCustomeremail() {
		return customeremail;
	}

	public void setCustomeremail(String customeremail) {
		this.customeremail = customeremail;
	}

	public String getPolicyPrice() {
		return policyPrice;
	}

	public void setPolicyPrice(String policyPrice) {
		this.policyPrice = policyPrice;
	}

	public String getPolicyCatagory() {
		return policyCatagory;
	}

	public void setPolicyCatagory(String policyCatagory) {
		this.policyCatagory = policyCatagory;
	}

	public String getPolicyName() {
		return policyName;
	}

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPolicyapplydate() {
		return policyapplydate;
	}

	public void setPolicyapplydate(String policyapplydate) {
		this.policyapplydate = policyapplydate;
	}

	

}
