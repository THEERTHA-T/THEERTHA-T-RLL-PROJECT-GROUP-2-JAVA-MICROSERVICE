package com.ipm.api.customerPolicyApply;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerApplyPolicyService {
	
	@Autowired
	public CustomerApplyPolicyRepo policyRepo;
	
	/*Applying for Policy*/
	public CustomerApplyPolicy ApplyPolicy(CustomerApplyPolicy policies) {
		// TODO Auto-generated method stub
		return policyRepo.save(policies);
	}
	

	/*Find AllPolicy*/
	public List<CustomerApplyPolicy> getCustomerApplication() {
		return policyRepo.findAll();
	}
	

	/*History of Applicaiton by Email*/
	public List<CustomerApplyPolicy> history(String cemail) {
		return policyRepo.findBycustomeremailIs(cemail);
	}
	
	/*Status Check*/
	public List<CustomerApplyPolicy> showDataStatus(String status) {
		List<CustomerApplyPolicy> data_status = policyRepo.findByStatusIs(status);
		return data_status;
	}

	
	
}
