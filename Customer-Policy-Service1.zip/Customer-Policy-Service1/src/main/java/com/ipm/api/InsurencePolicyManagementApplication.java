package com.ipm.api;

import com.ipm.api.customerPolicyApply.CustomerApplyPolicy;
import com.ipm.api.customerPolicyApply.CustomerApplyPolicyRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
public class InsurencePolicyManagementApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(InsurencePolicyManagementApplication.class, args);
    }

    @Autowired
    private CustomerApplyPolicyRepo customerApplyPolicyRepo;

    @Override
    public void run(String... args) throws Exception {
        customerApplyPolicyRepo.save(new CustomerApplyPolicy(null, "user1", "user1@gmail.com", "600000", "Health Insurance", "health", "Pending", TodysDate.todayDate()));
        customerApplyPolicyRepo.save(new CustomerApplyPolicy(null, "user2", "user1@gmail.com", "600000", "Health Insurance", "health", "Pending", TodysDate.todayDate()));
        customerApplyPolicyRepo.save(new CustomerApplyPolicy(null, "user2", "user1@gmail.com", "600000", "Health Insurance", "health", "Success", TodysDate.todayDate()));

    }
}
