package com.ipm.entity;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Customer {
private Long cid;
	private String cemail;
	private String cname;
	private String cpassword;
	private String cphno;
	private String cage;
	private String cgender;
	private String caddress;

	public Long getCid() {
		return cid;
	}

	public void setCid(Long cid) {
		this.cid = cid;
	}

	public String getCemail() {
		return cemail;
	}

	public void setCemail(String cemail) {
		this.cemail = cemail;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getCpassword() {
		return cpassword;
	}

	public void setCpassword(String cpassword) {
		this.cpassword = cpassword;
	}

	public String getCphno() {
		return cphno;
	}

	public void setCphno(String cphno) {
		this.cphno = cphno;
	}

	public String getCage() {
		return cage;
	}

	public void setCage(String cage) {
		this.cage = cage;
	}

	public String getCgender() {
		return cgender;
	}

	public void setCgender(String cgender) {
		this.cgender = cgender;
	}

	public String getCaddress() {
		return caddress;
	}

	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}

	public Customer(Long cid, String cemail, String cname, String cpassword, String cphno, String cage, String cgender,
			String caddress) {
		super();
		this.cid = cid;
		this.cemail = cemail;
		this.cname = cname;
		this.cpassword = cpassword;
		this.cphno = cphno;
		this.cage = cage;
		this.cgender = cgender;
		this.caddress = caddress;
	}

	public Customer() {
		super();
	}
	
	
	
	

}
