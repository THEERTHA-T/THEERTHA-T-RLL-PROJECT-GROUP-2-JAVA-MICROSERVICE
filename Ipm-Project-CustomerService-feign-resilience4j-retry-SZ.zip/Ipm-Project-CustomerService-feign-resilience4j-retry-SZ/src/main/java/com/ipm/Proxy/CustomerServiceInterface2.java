package com.ipm.Proxy;



import org.springframework.cloud.openfeign.FeignClient;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ipm.entity.Customer;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("CUSTOMER-SERVICE2")
public interface CustomerServiceInterface2 {
	
	@Retry(name = "CUSTOMER-SERVICE2")
	@CircuitBreaker(name = "CUSTOMER-SERVICE2", fallbackMethod = "fallbackMethodUpdateCustomer")
	 @PutMapping("/updatecustomer/{email}")
    public String updateCustomerByEmail(@PathVariable("email") String email, @RequestBody Customer customer);
	
	@Retry(name = "CUSTOMER-SERVICE2")
	@CircuitBreaker(name = "CUSTOMER-SERVICE2", fallbackMethod = "fallbackMethodDeleteCustomer")
	@DeleteMapping("/deletecustomer/{id}")
	public void deletecustomer(@PathVariable("id")Long id);

	 default String fallbackMethodUpdateCustomer(String email, Customer customer,Throwable throwable) {
	        System.err.println("Fallback: Request to update Customer by email failed.");
	        return "Fallback: Update customer failed.";
	    }
	
	default void fallbackMethodDeleteCustomer(Long id, Throwable throwable) {
	    System.err.println("Fallback: Request to delete Customer by id failed.");
	    throwable.printStackTrace(); }


}
