package com.ipm.Proxy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ipm.entity.Customer;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;


@FeignClient("CUSTOMER-SERVICE1")
public interface CustomerServiceInterface1 {

	@Retry(name = "CUSTOMER-SERVICE1")
	@CircuitBreaker(name = "CUSTOMER-SERVICE1", fallbackMethod = "fallbackMethodAddCustomer")
	 @PostMapping("/addcustomer")
	public Customer saveCustomer(Customer c);
		
	@Retry(name = "CUSTOMER-SERVICE1")
	@CircuitBreaker(name = "CUSTOMER-SERVICE1", fallbackMethod = "fallbackMethodShowAllCustomer")
	@GetMapping("/showcustomers")
	public List<Customer> showCustomers();
	
	@Retry(name = "CUSTOMER-SERVICE1")
	@CircuitBreaker(name = "CUSTOMER-SERVICE1", fallbackMethod = "fallbackMethodCount")
	@GetMapping("/countcustomer")
	public int countCustomer();
		
	
	// Fallback method for saveCustomer
	default Customer fallbackMethodAddCustomer(Customer c,Throwable throwable) {
	    System.err.println("Fallback: Request to Add Customer failed.");

	    // You can provide a default Customer or return null as needed.
	    return new Customer(); // Provide an appropriate default customer object.
	}
	
	
	// Fallback method for saveCustomer
	default List<Customer> fallbackMethodShowAllCustomer(Throwable throwable){
		    System.err.println("Fallback: Request to show Customer failed.");
		    return Collections.emptyList(); // Return an empty list as a fallback.

}
	

	
	

	
	
	
	

}
