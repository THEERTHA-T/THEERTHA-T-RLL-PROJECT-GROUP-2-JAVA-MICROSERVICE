package com.ipm.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipm.Exception.ProjectException;
import com.ipm.Proxy.CustomerServiceInterface1;
import com.ipm.Proxy.CustomerServiceInterface2;
import com.ipm.entity.Customer;

@RestController
@Scope("request")
@RequestMapping("/demo")
public class CustomerClientController {

	HttpStatus hs;

	@Autowired
	private CustomerServiceInterface1 customerServiceInterface1;

	@Autowired
	private CustomerServiceInterface2 customerServiceInterface2;
	
    private Logger log = LoggerFactory.getLogger(CustomerClientController.class);


    @PostMapping("/addcustomer")

	public ResponseEntity<Customer> addCustomer(@RequestBody Customer cc) {
    	log.debug("Request to Add customer done");
		return ResponseEntity.ok(customerServiceInterface1.saveCustomer(cc));
	}

	@GetMapping("/showcustomers")

	public List<Customer> showallCus() {
    	log.debug("Request to show all customer done");

		return customerServiceInterface1.showCustomers();
	}
	@GetMapping("/countcustomer")
	public int countCustomer() {

		List<Customer> cl = customerServiceInterface1.showCustomers();
    	log.debug("Request to count customer done");

		return cl.size();
	}
	@PutMapping("/updatecustomer/{email}")
	public String updateCustomer(@PathVariable("email") String email, @RequestBody Customer customer) {

		customerServiceInterface2.updateCustomerByEmail(email, customer);
			
		    	log.debug("Request to update customer done");

				return customer.getCname() + " Your data is updated";
			
		

	}

	@DeleteMapping("/deletecustomer/{id}")
	public String deleteUser(@PathVariable("id") Long id) {
		
			customerServiceInterface2.deletecustomer(id);
	    	log.debug("Request to delete customer done");

			return id + "  this Id of Customer Deleted";
		
	}

}
