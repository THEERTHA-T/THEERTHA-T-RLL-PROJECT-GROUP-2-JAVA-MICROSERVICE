package com.admin.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

@NoArgsConstructor
@AllArgsConstructor

public class Admin {

	private Integer id;

	private String adminname;

	private String adminemail;

	private String adminpassword;

	private int adminphno;

	private int adminage;

	private String admingender;

	private String adminadress;

	private String seniormanageremail;

	private String adminjoindate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAdminname() {
		return adminname;
	}

	public void setAdminname(String adminname) {
		this.adminname = adminname;
	}

	public String getAdminemail() {
		return adminemail;
	}

	public void setAdminemail(String adminemail) {
		this.adminemail = adminemail;
	}

	public String getAdminpassword() {
		return adminpassword;
	}

	public void setAdminpassword(String adminpassword) {
		this.adminpassword = adminpassword;
	}

	public int getAdminphno() {
		return adminphno;
	}

	public void setAdminphno(int adminphno) {
		this.adminphno = adminphno;
	}

	public int getAdminage() {
		return adminage;
	}

	public void setAdminage(int adminage) {
		this.adminage = adminage;
	}

	public String getAdmingender() {
		return admingender;
	}

	public void setAdmingender(String admingender) {
		this.admingender = admingender;
	}

	public String getAdminadress() {
		return adminadress;
	}

	public void setAdminadress(String adminadress) {
		this.adminadress = adminadress;
	}

	public String getSeniormanageremail() {
		return seniormanageremail;
	}

	public void setSeniormanageremail(String seniormanageremail) {
		this.seniormanageremail = seniormanageremail;
	}

	public String getAdminjoindate() {
		return adminjoindate;
	}

	public void setAdminjoindate(String adminjoindate) {
		this.adminjoindate = adminjoindate;
	}

	public Admin(Integer id, String adminname, String adminemail, String adminpassword, int adminphno, int adminage,
			String admingender, String adminadress, String seniormanageremail, String adminjoindate) {
		super();
		this.id = id;
		this.adminname = adminname;
		this.adminemail = adminemail;
		this.adminpassword = adminpassword;
		this.adminphno = adminphno;
		this.adminage = adminage;
		this.admingender = admingender;
		this.adminadress = adminadress;
		this.seniormanageremail = seniormanageremail;
		this.adminjoindate = adminjoindate;
	}

	public Admin() {
	}
}
