package com.admin.controller;

import java.util.List;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.admin.entity.Admin;
import com.admin.proxy.AdminServiceProxy;

@RestController
@CrossOrigin(origins = "*")
public class Adminclientcontroller {

	@Autowired
	private AdminServiceProxy adminServiceProxy;
//	
	private Logger log =LoggerFactory.getLogger(Adminclientcontroller.class);


	@GetMapping("/get-admins")
	public ResponseEntity<List<Admin>> getAllAdmins() {
		ResponseEntity<List<Admin>> admins=adminServiceProxy.getAllAdmins();
		log.debug("In getAllAdmins with return value Admin: " + admins);

		return admins;
	}
	


	@GetMapping("/get-admins/{id}")
	public ResponseEntity<Admin> getAdminById(@PathVariable("id") int id) {
	//	return adminServiceProxy.getAdminById(id);
		
		ResponseEntity<Admin> adminbyid=adminServiceProxy.getAdminById(id);
		
		log.debug("In getAllAdmins with return value Admin: " + adminbyid);
		
		return adminbyid;
	}

	@PostMapping("/add-admin")
	public ResponseEntity<Admin> addAdmin(@RequestBody Admin admin) {
		// Delegate the request to the AdminServiceProxy to make the remote service call
		//ResponseEntity<Admin> response = adminServiceProxy.addAdmin(admin);
		ResponseEntity<Admin> addadmin=adminServiceProxy.addAdmin(admin);
		log.debug("In getAllAdmins with return value Admin: " + addadmin);
		// You can add additional logic or error handling here if needed

		return addadmin;
	}

	@PutMapping("/adminupdate")
	public ResponseEntity<Admin> updateAdmin(@RequestBody Admin admin) {
		
		ResponseEntity<Admin> adminupdate=adminServiceProxy.updateAdmin(admin);
		
		log.debug("In getAllAdmins with return value Admin: " + adminupdate);
		// You can add additional logic or error handling here if needed

		return adminupdate;
		
		
		//return adminServiceProxy.updateAdmin(admin);
	}

	@DeleteMapping("/admins/{id}")
	public ResponseEntity<Void> deleteAdmin(@PathVariable("id") int id) {
		
		ResponseEntity<Void> admindelete=adminServiceProxy.deleteAdmin(id);
		
		log.debug("In getAllAdmins with return value Admin: " + admindelete);
		// You can add additional logic or error handling here if needed

		return admindelete;
		
		
		
	//	return adminServiceProxy.deleteAdmin(id);
	}

	@PostMapping(value = "/login", produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_VALUE })
	public String login(@RequestBody Admin login) {
		String username = login.getAdminname();
		String password = login.getAdminpassword();

		ResponseEntity<List<Admin>> adminResponse = adminServiceProxy.getAllAdmins();
		
		log.debug("In getAllAdmins with return value Admin: " + adminResponse);

		if (adminResponse.getStatusCode().is2xxSuccessful()) {
			List<Admin> admins = adminResponse.getBody();
			for (Admin admin : admins) {
				if (admin.getAdminname().equals(username) && admin.getAdminpassword().equals(password)) {
					return "Login successful!";
				}
			}
		}

		return "Login failed. Invalid username or password.";
	}
}

////	}
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.admin.entity.Admin;
//import com.admin.proxy.AdminServiceProxy;
//
//@RestController
//@CrossOrigin(origins = "*")
//public class Adminclientcontroller {
//
//    @Autowired
//    private AdminServiceProxy adminServiceProxy;
//
//    @GetMapping("/admins")
//    public ResponseEntity<List<Admin>> getAllAdmins() {
//        return adminServiceProxy.getAllAdmins();
//    }
//
//    @GetMapping("/admins/{id}")
//    public ResponseEntity<Admin> getAdminById(@PathVariable("id") int id) {
//        return adminServiceProxy.getAdminById(id);
//    }
//
//    @PostMapping("/admins")
//    public ResponseEntity<Admin> addAdmin(@RequestBody Admin admin) {
//        return adminServiceProxy.addAdmin(admin);
//    }
//
//    @PutMapping("/admins")
//    public ResponseEntity<Admin> updateAdmin(@RequestBody Admin admin) {
//        return adminServiceProxy.updateAdmin(admin);
//    }
//
//    @DeleteMapping("/admins/{id}")
//    public ResponseEntity<Void> deleteAdmin(@PathVariable("id") int id) {
//        return adminServiceProxy.deleteAdmin(id);
//    }

    // Add other controller methods similarly using adminServiceProxy


