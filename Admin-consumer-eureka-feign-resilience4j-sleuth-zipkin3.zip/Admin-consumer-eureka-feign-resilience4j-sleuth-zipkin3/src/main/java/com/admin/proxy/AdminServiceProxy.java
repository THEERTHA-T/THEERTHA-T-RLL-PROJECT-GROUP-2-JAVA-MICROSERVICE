package com.admin.proxy;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.admin.entity.Admin;

import java.util.List;
import java.util.ArrayList;

@FeignClient(name = "admin-service")
public interface AdminServiceProxy {

	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodForGetAllAdmins")
	@GetMapping("/admins")
	ResponseEntity<List<Admin>> getAllAdmins();

	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodForGetAdminById")
	@GetMapping("/admins/{id}")
	ResponseEntity<Admin> getAdminById(@PathVariable("id") int id);

	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodForAddAdmin")
	@PostMapping("/add-admin")
	ResponseEntity<Admin> addAdmin(@RequestBody Admin admin);

	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodForUpdateAdmin")
	@PutMapping("/adminupdate")
	ResponseEntity<Admin> updateAdmin(@RequestBody Admin admin);

	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodForDeleteAdmin")
	@DeleteMapping("/admins/{id}")
	ResponseEntity<Void> deleteAdmin(@PathVariable("id") int id);

	@Retry(name = "admin-service")
	@CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodForLogin")
	@PostMapping("/login")
	ResponseEntity<Admin> login(@RequestParam("username") String username, @RequestParam("password") String password);

	// fall back method for login
	default ResponseEntity<Admin> fallbackMethodForLogin(String username, String password, Throwable throwable) {
		System.out.println("Fallback Method For Login!!");
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	// fall back method for all admins
	default ResponseEntity<List<Admin>> fallbackMethodForGetAllAdmins(Throwable throwable) {
		System.err.println("FallBack method for all admins.......!");

		List<Admin> defaultAdminList = new ArrayList<>();
		defaultAdminList.add(new Admin(1, "Default Admin 1", "admin1@example.com", "password1", 1234567890, 30, "Male",
				"Default Address 1", "manager1@example.com", "2023-09-09"));
		defaultAdminList.add(new Admin(2, "Default Admin 2", "admin2@example.com", "password2", 987653210, 25, "Female",
				"Default Address 2", "manager2@example.com", "2023-09-10"));

		return ResponseEntity.ok(defaultAdminList);
	}

// fall back method for admin by id
	default ResponseEntity<Admin> fallbackMethodForGetAdminById(int id, Throwable throwable) {
		System.err.println("Fall back Method For To see admin By id...!");

		// Create and return a default Admin object
		Admin defaultAdmin = new Admin();
		defaultAdmin.setId(1); // Set some default values
		defaultAdmin.setAdminname("fallback Admin");
		defaultAdmin.setAdminemail("fallback@example.com");
		defaultAdmin.setAdminadress("fallback");
		defaultAdmin.setAdminage(10);
		defaultAdmin.setAdmingender("Female");

		return ResponseEntity.ok(defaultAdmin);
	}

	// fallback method add admin
	default ResponseEntity<Admin> fallbackMethodForAddAdmin(Admin admin, Throwable throwable) {
		System.err.println("Fallback Method For to add admin..!");
		Admin defaultAdmin = new Admin();
		defaultAdmin.setId(-1); // Set some default values
		defaultAdmin.setAdminname("Fallback 1");
		defaultAdmin.setAdminemail("admin11@example.com");
		defaultAdmin.setAdminadress("fallback");
		defaultAdmin.setAdminage(15);

		return ResponseEntity.ok(defaultAdmin);

	}

	// fall back method for update admin
	default ResponseEntity<Admin> fallbackMethodForUpdateAdmin(Admin admin, Throwable throwable) {
		System.err.println("Fall back method for update admin");
		Admin defaultAdmin = new Admin();
		defaultAdmin.setId(2); // Set some default values
		defaultAdmin.setAdminname("Fallback 2");
		defaultAdmin.setAdminemail("admin@example.com");

		return ResponseEntity.ok(defaultAdmin);

	}

	default ResponseEntity<Void> fallbackMethodForDeleteAdmin(int id, Throwable throwable) {
		System.out.println("Fallback method for delete admin by id");

		return ResponseEntity.status(HttpStatus.OK).build();
	}
}
