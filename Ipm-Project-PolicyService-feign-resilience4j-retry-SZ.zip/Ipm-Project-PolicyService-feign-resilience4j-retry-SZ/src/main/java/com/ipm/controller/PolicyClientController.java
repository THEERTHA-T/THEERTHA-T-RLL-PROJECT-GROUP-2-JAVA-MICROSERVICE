package com.ipm.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ipm.Proxy.PolicyServiceInterface1;
import com.ipm.Proxy.PolicyServiceInterface2;
import com.ipm.entity.Policy;

@RestController
@Scope("request")
public class PolicyClientController {

	HttpStatus hs;

	@Autowired
	private PolicyServiceInterface1 policyServiceInterface1;

	@Autowired
	private PolicyServiceInterface2 policyServiceInterface2;
	
    private Logger log = LoggerFactory.getLogger(PolicyClientController.class);


	@PostMapping("/addpolicys")
	public HttpStatus addPolicy(@RequestBody Policy po) {
        log.debug("------creating a Add Policy request------");
		policyServiceInterface1.addPolicy(po);
        log.debug("------Add Policy Request Success------");

		return hs.CREATED;
	}

	@GetMapping("/getpolicy/{id}")
	public ResponseEntity<Policy> getPolicyById(@PathVariable Long id) {
        log.debug("------Creating a Get Policy request------");

	    ResponseEntity<Policy> policy = policyServiceInterface1.getPolicyById(id);

	    if (policy != null) {
	        log.debug("------Get Policy request success------");

	        return policy; // Return ResponseEntity<Policy> directly
	    } else {
	        return ResponseEntity.notFound().build();
	    }
	}


	@GetMapping("/countpolicy")
	public int countPolicy() {
        log.debug("------creating a Count Policy request------");

		List<Policy> total_policy = policyServiceInterface2.getPolicy();
        log.debug("------Count Policy request success------");

		return total_policy.size();
	}


	@GetMapping("/getpolicys")
	public List<Policy> getPolicy() {
        log.debug("------Get All Policy request------");

		return policyServiceInterface2.getPolicy();
		

	}

	// Update Policy by id
	@PutMapping("/updatepolicy/{id}")
	public ResponseEntity<Void> updatePolicy(@PathVariable("id") Long id, @RequestBody Policy p) {
        log.debug("------creating a Update Policy request------");

		ResponseEntity<Void> updatedPolicy = policyServiceInterface2.updatePolicy(id, p);
	    if (updatedPolicy != null) {
	        log.debug("------Update Policy request success------");
	        return ResponseEntity.ok().build(); // 200 OK
	    } else {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // 500 Internal Server Error
	    }
	}


	@DeleteMapping("/deletepolicy/{id}")
	public HttpStatus deletePolicyById(@PathVariable Long id) {
        log.debug("------creating a Delete Policy request------");
			policyServiceInterface2.deletePolicyById(id);
	        log.debug("------Delete Policy request success------");
			return HttpStatus.OK;
		
	}

}
