package com.ipm.Proxy;

import java.util.Collections;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ipm.entity.Policy;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("POLICY-SERVICE2")
public interface PolicyServiceInterface2 {
	
	@Retry(name = "POLICY-SERVICE2")
	@CircuitBreaker(name = "POLICY-SERVICE2", fallbackMethod = "fallbackMethodGetPolicy")
	
	@GetMapping("/getpolicys")
	public List<Policy> getPolicy();

	
	
	// Update Policy by id
	@Retry(name = "POLICY-SERVICE2")
	@CircuitBreaker(name = "POLICY-SERVICE2", fallbackMethod = "fallbackMethodUpdatePolicy")
	@PutMapping("/updatepolicy/{id}")
	public ResponseEntity<Void>  updatePolicy(@PathVariable("id") Long id, @RequestBody Policy p);

	@Retry(name = "POLICY-SERVICE2")
	@CircuitBreaker(name = "POLICY-SERVICE2", fallbackMethod = "fallbackMethodDeletePolicy")
	@DeleteMapping("/deletepolicy/{id}")
	public HttpStatus deletePolicyById(@PathVariable Long id);
	
	
	
	//fallback
    default List<Policy> fallbackMethodGetPolicy(Throwable throwable) {
		System.err.println("Fallback : Request to createChequebook is failed.");

        return Collections.emptyList();
    }
    

 // Fallback method for updatePolicy
    default ResponseEntity<Void> fallbackMethodUpdatePolicy(Long id, Policy p, Throwable throwable) {
        System.err.println("Fallback : Request to updatePolicy is failed.");
        // Return a default Policy object or another appropriate response
        return ResponseEntity.ok().build(); // 200 OK
    }
    

    default HttpStatus fallbackMethodDeletePolicy(@PathVariable Long id,Throwable throwable) {
		System.err.println("Fallback : Request to createChequebook is failed.");

        return HttpStatus.INTERNAL_SERVER_ERROR;
    }
    
    
    
    
    
    

	

}
