package com.ipm.Proxy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ipm.entity.Policy;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;


@FeignClient("POLICY-SERVICE1")
public interface PolicyServiceInterface1 {

	@Retry(name = "POLICY-SERVICE1")
	@CircuitBreaker(name = "POLICY-SERVICE1", fallbackMethod = "fallbackMethodAddPolicy")
	@PostMapping("/addpolicys")
	public HttpStatus addPolicy(@RequestBody Policy po);

	@Retry(name = "POLICY-SERVICE1")
	@CircuitBreaker(name = "POLICY-SERVICE1", fallbackMethod = "fallbackMethodGetPolicyById")
	@GetMapping("/getpolicy/{id}")
    public ResponseEntity<Policy> getPolicyById(@PathVariable Long id);
	
	// Counting Policies
	@Retry(name = "POLICY-SERVICE1")
	@CircuitBreaker(name = "POLICY-SERVICE1", fallbackMethod = "fallbackMethodCountPolicy")
	@GetMapping("/countpolicy")
	public List<Policy> countPolicy();
	
	
	
	// Fallback method for addPolicy
    default HttpStatus fallbackMethodAddPolicy(@RequestBody Policy po,Throwable throwable) {
		System.err.println("Fallback : Request to Add Policy is failed.");
		 List<Policy> fallbackList = new ArrayList<>();
	        Policy policy = new Policy();
	        policy.setPid(0L); // Set an ID or other data as needed
	        policy.setPolicyname("Fallback Policy");
	        fallbackList.add(policy);
	        
        return HttpStatus.OK;
    }

    // Fallback method for getPolicyById
    default ResponseEntity<Policy> fallbackMethodGetPolicyById(Long id,Throwable throwable) {
         Policy defaultPolicy = new Policy(); // Create a default Policy object
 		System.err.println("Fallback : Request to Get Policy By ID is failed.");

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(defaultPolicy);
    }

    default List<Policy> fallbackMethodCountPolicy(Throwable throwable) {
        System.err.println("Fallback : Request to count Policy is failed.");
        
        // You can return a custom list or handle the fallback logic here
        List<Policy> fallbackList = new ArrayList<>();
        Policy policy = new Policy();
        policy.setPid(0L); // Set an ID or other data as needed
        policy.setPolicyname("Fallback Policy");
        fallbackList.add(policy);
        
        return fallbackList;
    }


}
