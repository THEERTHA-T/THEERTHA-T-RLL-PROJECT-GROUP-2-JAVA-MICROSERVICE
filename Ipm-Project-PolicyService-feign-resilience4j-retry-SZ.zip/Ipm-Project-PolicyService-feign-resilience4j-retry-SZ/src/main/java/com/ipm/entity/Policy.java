package com.ipm.entity;


import com.ipm.TodaysDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public class Policy {

		private Long pid;
		private String policyname;
		private String policycatagory;
		private String addDateOfPolicy = TodaysDate.todayDate();
		public Long getPid() {
			return pid;
		}
		public void setPid(Long pid) {
			this.pid = pid;
		}
		public String getPolicyname() {
			return policyname;
		}
		public void setPolicyname(String policyname) {
			this.policyname = policyname;
		}
		public String getPolicycatagory() {
			return policycatagory;
		}
		public void setPolicycatagory(String policycatagory) {
			this.policycatagory = policycatagory;
		}
		public String getAddDateOfPolicy() {
			return addDateOfPolicy;
		}
		public void setAddDateOfPolicy(String addDateOfPolicy) {
			this.addDateOfPolicy = addDateOfPolicy;
		}

		
}
