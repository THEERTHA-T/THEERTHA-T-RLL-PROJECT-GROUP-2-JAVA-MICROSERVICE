package com.ipm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.beans.factory.annotation.Qualifier;

import com.ipm.entity.Customer;
import com.ipm.repository.CustomerRepository;
@EnableEurekaClient

@SpringBootApplication
public class IpmProjectPolicyServiceApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(IpmProjectPolicyServiceApplication.class, args);
    }

    @Autowired
    @Qualifier("customerRepository")
    private CustomerRepository customerRepository;

    @Override
    public void run(String... args) throws Exception {
    	customerRepository.save(new Customer(null, "user1@gmail.com", "user1","pswd1","9876567876","33","Male","pune"));
    	customerRepository.save(new Customer(null, "user2@gmail.com", "user2","pswd1","9876567876","33","Male","pune"));
    	customerRepository.save(new Customer(null, "user3@gmail.com", "user3","pswd1","9876567876","33","Male","pune"));
    	customerRepository.save(new Customer(null, "user4@gmail.com", "user4","pswd1","9876567876","33","Male","pune"));
    	customerRepository.save(new Customer(null, "user5@gmail.com", "user5","pswd1","9876567876","33","Male","pune"));

    
    }
}
