package com.ipm.services;

import java.util.List;

import com.ipm.entity.Customer;

public interface ICustomerService {
	
	// Insert data in Database
		public Customer saveCustomer(Customer c);
		public List<Customer> showCustomers();
		
	}



