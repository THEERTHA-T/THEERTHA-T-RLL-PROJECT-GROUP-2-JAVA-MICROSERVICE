package com.ipm.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ipm.TodaysDate;
import com.ipm.entity.Customer;
import com.ipm.repository.CustomerRepository;

@Service(value = "customerService")
@Scope("singleton")
@Transactional
public class CustomerService {
	@Autowired
	CustomerRepository crepo;

	public Customer saveCustomer(Customer c) {

		return crepo.save(c);

	}
	
	// Show all customer details
		public List<Customer> showCustomers() {

			return crepo.findAll();

		}
}
