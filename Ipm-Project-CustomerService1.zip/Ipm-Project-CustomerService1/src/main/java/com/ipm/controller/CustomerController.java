package com.ipm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ipm.entity.Customer;
import com.ipm.services.CustomerService;

@RestController
@CrossOrigin("http://localhost:4200")

public class CustomerController {
	@Autowired
	CustomerService customerService;
	HttpStatus hs;

	@PostMapping("/addcustomer")

	public ResponseEntity<Customer> addCustomer(@RequestBody Customer cc) {
		return ResponseEntity.ok(customerService.saveCustomer(cc));
	}

	@GetMapping("/showcustomers")

	public List<Customer> showallCus() {
		return customerService.showCustomers();
	}
	@GetMapping("/countcustomer")
	public int countCustomer() {
		List<Customer> cl = customerService.showCustomers();

		return cl.size();
	}
}
