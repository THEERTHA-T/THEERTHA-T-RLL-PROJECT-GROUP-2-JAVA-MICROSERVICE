package com.questions.proxy;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.ArrayList;

import com.questions.entity.PublicQuestion;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;

@FeignClient("public-question-service") // Specify the name and base URL of the target service

public interface QuestionServiceFeignClient {

	


	@Retry(name = "public-question-service")
	@CircuitBreaker(name = "public-question-service", fallbackMethod = "fallbackMethodGetSMS")
    @GetMapping(value = "/getunknownsms")
	public List<PublicQuestion> getAllSms();
	
	@Retry(name = "public-question-service")
	@CircuitBreaker(name = "public-question-service", fallbackMethod = "fallbackMethodSaveSms")
	 @PostMapping(value = "/addunknowsms")
	public HttpStatus saveSms(@RequestBody PublicQuestion sms);
	
	@Retry(name = "public-question-service")
	@CircuitBreaker(name = "public-question-service", fallbackMethod = "fallbackMethodDeleteSms")
	@DeleteMapping(value = "/deleteunknownsms/{id}")
    String deleteSms(@PathVariable("id") Long id);
	
	
	public default String fallbackMethodDeleteSms(Long id, Throwable throwable) {
        System.err.println("Fallback: Request to delete SMS with ID " + id + " failed.");
		return "ok";
    }

    // Fallback method for post request
	
    public default HttpStatus fallbackMethodSaveSms(PublicQuestion sms, Throwable throwable) {
        System.err.println("Fallback: Request to save SMS failed.");
        List<PublicQuestion> fallbackList = new ArrayList<>();
        PublicQuestion policy = new PublicQuestion();
        policy.setId(0L); // Set an ID or other data as needed
        policy.setname("Fallback Policy");
        policy.setEmail("fallback@gmail.com");
        fallbackList.add(policy);
        return HttpStatus.INTERNAL_SERVER_ERROR;
    }

	default List<PublicQuestion> fallbackMethodGetSMS(Throwable throwable) {
        System.err.println("Fallback : Request to get unknown sms is failed.");
        return Collections.emptyList(); // Return an empty list or handle the fallback appropriately.
    }

	 

	   //	public String deleteSms(Long id);
    

}
