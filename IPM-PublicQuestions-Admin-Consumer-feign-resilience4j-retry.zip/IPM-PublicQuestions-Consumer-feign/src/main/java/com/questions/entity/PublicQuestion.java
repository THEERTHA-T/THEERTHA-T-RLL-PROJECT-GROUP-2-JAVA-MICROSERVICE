package com.questions.entity;


import lombok.AllArgsConstructor;
import lombok.Data;

import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class PublicQuestion {

	
	private Long id;
	
	private String email;
	
	private String name;
	
	private String sms;
	
	
//public PublicQuestion(int i, String string, String string2) {
//		// TODO Auto-generated constructor stub
//	}
public PublicQuestion() {
	// TODO Auto-generated constructor stub
}
public void Question() {}
	 //Constructor with all fields
     public void Question(Long id, String email, String name, String sms) {
         this.id = id;
         this.email = email;
         this.name = name;
         this.sms = sms;
        
     }
    // Getters and Setters
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	public String getsms() {
		return sms;
	}
	public void setsms(String sms) {
		this.sms = sms;
	}
	@Override
	public String toString() {
		return "Question [id=" + id + ", email=" + email + ", name=" + name + ", sms=" + sms + "]";
	}
	public PublicQuestion(long i, String email, String name, String sms) {
		super();
		this.id = i;
		this.email = email;
		this.name = name;
		this.sms = sms;
	}
	
    
	}
    
    
	
