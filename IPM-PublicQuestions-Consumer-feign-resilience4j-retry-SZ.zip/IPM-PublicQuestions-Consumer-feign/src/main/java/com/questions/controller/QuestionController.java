package com.questions.controller;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.questions.entity.PublicQuestion;
import com.questions.proxy.QuestionServiceFeignClient;

@RestController
@Scope("request")
@RequestMapping("/demo")
public class QuestionController {

    @Autowired
    private QuestionServiceFeignClient questionServiceFeignClient;

    private Logger log = LoggerFactory.getLogger(QuestionController.class);

    @GetMapping("/getunknownsms")
    public ResponseEntity<List<PublicQuestion>> getsmss() {
        log.debug("------creating a get sms request------");
        List<PublicQuestion> smsList = questionServiceFeignClient.getAllSms();
        return new ResponseEntity<>(smsList, HttpStatus.OK);
    }

    @DeleteMapping("/deleteunknownsms/{id}")
    public ResponseEntity<String> deleteSms(@PathVariable("id") Long id) {
        try {
            String result = questionServiceFeignClient.deleteSms(id);
            log.debug("Deleted question with ID: {}", id);
            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error deleting SMS with ID: {}", id, e);
            return new ResponseEntity<>("Failed to delete SMS with ID: " + id, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    
    @PostMapping("/addunknowsms")
	public HttpStatus saveSms(@RequestBody PublicQuestion sms) {

			 questionServiceFeignClient.saveSms(sms);
	            log.debug("Saved SMS with ID: {}", sms.getId());
	           			return HttpStatus.CREATED;
		
	}
   
}
