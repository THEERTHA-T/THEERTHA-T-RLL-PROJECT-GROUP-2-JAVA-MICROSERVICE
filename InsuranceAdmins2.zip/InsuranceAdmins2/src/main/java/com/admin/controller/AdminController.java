package com.admin.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.admin.entity.Admin;
import com.admin.service.AdminRepository;
import com.admin.service.IAdminservice;
import com.ipm.api.exceptions.ProjectExecption;

@RestController
@Scope("request")

public class AdminController {

	@Autowired
	@Qualifier("adminService")
	private IAdminservice adminService;

	private Logger log = LoggerFactory.getLogger(AdminController.class);

	@GetMapping(value = "/admins", produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<Admin> getAllAdmins() {

		log.debug("In this getAll admins ");
		return adminService.getAllAdmins();
	}

	@PostMapping(value = "/add-admin", produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseStatus(code = HttpStatus.CREATED)
	public Admin addAdmin(@RequestBody Admin admin) {
		log.debug("In Add admin with return valu admin: " + admin);
		return adminService.addAdmin(admin);
	}

	@GetMapping("/admins/{id}")

	public Admin showaCustomerById(@PathVariable("id") int id) {

		log.debug("In getBookById with Id:" + id);
		Admin admin = adminService.getAdminById(id);
		log.debug("In getAdminById with return value admin: " + admin);
		return admin;

	}

	@PutMapping(value = "/adminupdate", produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseStatus(code = HttpStatus.OK)
	public Admin updateBook(@RequestBody Admin adminupdate) {

		log.debug("In adminupdate with return value admin: " + adminupdate);
		return adminService.updateAdmin(adminupdate);

	}

	@DeleteMapping(value = "/admins/{id}")
	// @ResponseStatus(code = HttpStatus.NO_CONTENT)
	public String deleteBookById(@PathVariable("id") Integer id) {
		try {
			adminService.deletAdminById(id);
			log.debug("In DeleteAdminById with return value admin: " + id);
			System.out.println(id + "id deleted");
			return id + " " + "id deleted";

		} catch (Exception e) {
			throw new ProjectExecption();

		}

	}

	@PostMapping(value = "/login", produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_VALUE })
	public String login(@RequestBody Admin login) {
		String username = login.getAdminname();
		String password = login.getAdminpassword();
		List<Admin> admins = adminService.getAllAdmins();
		log.debug("In Login  with return value admin: " + admins);
		for (Admin admin : admins) {
			if (admin.getAdminname().equals(username) && admin.getAdminpassword().equals(password)) {
				return "Login successful!";
			}
		}

		return "Login failed. Invalid username or password.";
	}

}
