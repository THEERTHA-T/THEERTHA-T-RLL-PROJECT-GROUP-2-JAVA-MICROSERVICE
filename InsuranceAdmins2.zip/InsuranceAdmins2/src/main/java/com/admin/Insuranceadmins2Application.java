package com.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import com.admin.entity.Admin;
import com.admin.service.AdminRepository;

import brave.sampler.Sampler;

import org.springframework.boot.CommandLineRunner;

@EnableEurekaClient
@SpringBootApplication
public class Insuranceadmins2Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Insuranceadmins2Application.class, args);
	}

	@Autowired
	@Qualifier("adminRepository")
	private AdminRepository adminRepository;

	@Bean
	public Sampler getSampler() {

		// return Sampler.create(0.5f);
		return Sampler.ALWAYS_SAMPLE;
	}

	@Override
	public void run(String... args) throws Exception {

		adminRepository.save(new Admin(1, "kaveri", "kanna@gmail.com", "kaveri123", 987567899, 23, "Female", "Admin",
				"ka@gmail.com", "4-6-2023"));
		adminRepository.save(new Admin(2, "teju", "sai@gmail.com", "kaveri123", 987567899, 23, "male", "Admin",
				"sai@gmail.com", "4-9-2023"));

		System.out.println(adminRepository.findAll());
	}

}
