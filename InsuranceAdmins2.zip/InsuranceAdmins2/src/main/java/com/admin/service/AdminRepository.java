package com.admin.service;


import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Repository;

import com.admin.entity.Admin;

//import com.mphasis.domain.Book;
@Repository(value = "adminRepository")
@Scope("singleton")
public interface AdminRepository extends JpaRepository<Admin, Integer>{

	Admin findByAdminemail(String email);
	//Admin getByEmail(String email);

	Admin getAdminById(int id);
	
	String deleteAdminById(Integer id);

	//Admin findByAdminemail(String email);

	

	

	
}
