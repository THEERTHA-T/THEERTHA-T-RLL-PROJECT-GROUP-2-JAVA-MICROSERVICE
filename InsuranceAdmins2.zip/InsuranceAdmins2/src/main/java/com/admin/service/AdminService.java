package com.admin.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.admin.entity.Admin;
//import com.ipm.api.admin.Admin;
@Service(value = "adminService")
@Scope("singleton")
@Transactional
public class AdminService implements IAdminservice{


		@Autowired
		@Qualifier("adminRepository")
		private AdminRepository adminRepository;

		@Override
		public List<Admin> getAllAdmins() {
			// TODO Auto-generated method stub
			return adminRepository.findAll();
		}

		@Override
		public Admin addAdmin(Admin admin) {
			// TODO Auto-generated method stub
			return adminRepository.save(admin);
		}

//		@Override
//		public Admin findByEmail(String email) {
//			// TODO Auto-generated method stub
//			return adminRepository.findByAdminemail(email) ;
//		}

		@Override
		public Admin updateAdmin(Admin admin) {
			// TODO Auto-generated method stub
			return adminRepository.save(admin);
		}

//		@Override
//		public Admin  deletAdminById(Integer id) {
//			
//			// TODO Auto-generated method stub
////			adminRepository.deleteById(id);
//			return adminRepository.deleteById(id);
//		}

		@Override
		public String deletAdminById(Integer id) {
			
			// TODO Auto-generated method stub
			 return adminRepository.deleteAdminById(id);
		}
		
		@Override
		public Admin getAdminById(int id) {
			// TODO Auto-generated method stub
			return adminRepository.getAdminById(id);
		}

	
		

		
		}
