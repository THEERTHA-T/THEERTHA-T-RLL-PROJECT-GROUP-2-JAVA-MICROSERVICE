package com.admin.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.admin.entity.Admin;

@Service(value = "adminService")
@Scope("singleton")
@Transactional
public class AdminService implements IAdminservice {

	@Autowired
	@Qualifier("adminRepository")
	private AdminRepository adminRepository;

	@Override
	public List<Admin> getAllAdmins() {

		return adminRepository.findAll();
	}

	@Override
	public Admin addAdmin(Admin admin) {
		return adminRepository.save(admin);
	}

	@Override
	public Admin updateAdmin(Admin admin) {

		return adminRepository.save(admin);
	}

	@Override
	public String deletAdminById(Integer id) {

		return adminRepository.deleteAdminById(id);
	}

	@Override
	public Admin getAdminById(int id) {

		return adminRepository.getAdminById(id);
	}

}
