package com.admin.service;

import java.util.List;
import java.util.Optional;

import com.admin.entity.Admin;

public interface IAdminservice {

	List<Admin> getAllAdmins();

	Admin addAdmin(Admin admin);

	//Admin getBookByEmail(String email);

//	Admin findByEmail(String email);

	Admin updateAdmin(Admin admin);

	String deletAdminById(Integer id);

	//Admin findById(int id);

	Admin getAdminById(int id);

	}
