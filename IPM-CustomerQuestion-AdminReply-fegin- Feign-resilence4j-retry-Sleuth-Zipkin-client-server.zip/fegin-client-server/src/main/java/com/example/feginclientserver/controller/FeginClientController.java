package com.example.feginclientserver.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.feginclientserver.dto.AdminReply;
import com.example.feginclientserver.dto.AnswerResponse;
import com.example.feginclientserver.dto.CustomerQuestions;
import com.example.feginclientserver.service.CustomerQuestionsService;

//import lombok.extern.slf4j.Slf4j;


@RestController
@RequestMapping("/fegin-client")
//@Slf4j
public class FeginClientController {
	
	@Autowired
	CustomerQuestionsService customerQuestionsService;
	private Logger log = LoggerFactory.getLogger(FeginClientController.class);	
	@GetMapping("answer/{qId}")
	public AnswerResponse getAnswerForQuestion(@PathVariable("qId") Long qId) {
		AnswerResponse answerResponse= customerQuestionsService.getAnswerForQid(qId);
		log.info("in getAnswerForQuestion got ANswer for question id {}",answerResponse);
		return answerResponse;
		
	}
	@GetMapping("history")
	public List<AnswerResponse> getAnswerForeQuestion() {
		List<AnswerResponse> answerResponses =   customerQuestionsService.getAllQuestions();
		log.debug("in getAnswerForeQuestion questions and answers for all question {}", answerResponses );
		return answerResponses;
		
	}
	
	@GetMapping("admin/questions/all")
	public List<CustomerQuestions> getAllQuestions() {
		
		List<CustomerQuestions> customerQuestions = customerQuestionsService.getAllQuestionsAdmin();
		
		log.debug("in getAllQuestions getting all questions without answers {}",customerQuestions  );
		return customerQuestions;
		
	}

	@PostMapping("saveQuestion")
	public String saveQuestion(@RequestBody CustomerQuestions cq) {
//		log.info("input customer questions {}",cq);
		String response = customerQuestionsService.saveQuestion(cq);
		log.debug("in saveQuestion saved question with {}", cq);
		return response;
		
	}
	@PostMapping("saveAnswer")
	public String saveAnswer(@RequestBody AdminReply adminReply) {
		String response = customerQuestionsService.saveAnswer(adminReply);
		log.debug("in saveAnswer saved answer with {}",adminReply);
		return response;
		
	}
	
}
