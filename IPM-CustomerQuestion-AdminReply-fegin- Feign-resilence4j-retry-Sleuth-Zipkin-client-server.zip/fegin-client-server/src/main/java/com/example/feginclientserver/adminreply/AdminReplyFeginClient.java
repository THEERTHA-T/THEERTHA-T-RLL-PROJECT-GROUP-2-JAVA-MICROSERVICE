package com.example.feginclientserver.adminreply;


import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.feginclientserver.dto.AdminReply;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("ADMIN-REPLY")
public interface AdminReplyFeginClient {

	@Retry(name = "ADMIN-REPLY")
	@CircuitBreaker(name = "ADMIN-REPLY", fallbackMethod = "fallbackMethodSaveAdminReply")
	@PostMapping(value = "/save")
	public HttpStatus saveAdminReply(@RequestBody AdminReply adminReply);

	@Retry(name = "ADMIN-REPLY")
	@CircuitBreaker(name = "ADMIN-REPLY", fallbackMethod = "fallbackMethodGetAllAdminReplies")
	@GetMapping(value = "/all")
	public List<AdminReply> getAllAdminReplies();

	@Retry(name = "ADMIN-REPLY")
	@CircuitBreaker(name = "ADMIN-REPLY", fallbackMethod = "fallbackMethodGetAdminReplyById")
	@GetMapping(value = "/{answerId}")
	public AdminReply getAdminReplyById(@PathVariable("answerId") Long answerId);

	// Fallback method for saveAdminReply
	default HttpStatus fallbackMethodSaveAdminReply(@RequestBody AdminReply adminReply, Throwable throwable) {
		System.err.println("Fallback: Request to saveAdminReply is failed.");
		return HttpStatus.GATEWAY_TIMEOUT; // You can handle the fallback logic here
	}

	// Fallback method for getAllAdminReplies
	default List<AdminReply> fallbackMethodGetAllAdminReplies(Throwable throwable) {
		System.err.println("Fallback: Request to getAllAdminReplies is failed.");
		List<AdminReply> fallbackList = new ArrayList<AdminReply>();
		AdminReply defaultAdminReply = new AdminReply();
		defaultAdminReply.setQanswer("fallback answer");
		defaultAdminReply.setQanswerdate("fallback date");
		fallbackList.add(defaultAdminReply);
		return fallbackList;
	}

	// Fallback method for getAdminReplyById
	default AdminReply fallbackMethodGetAdminReplyById(Long answerId, Throwable throwable) {
		System.err.println("Fallback: Request to getAdminReplyById is failed.");
		AdminReply defaultAdminReply = new AdminReply();
		defaultAdminReply.setQanswer("fallback answer");
		defaultAdminReply.setQanswerdate("fallback date");
		defaultAdminReply.setQid(0L);
		// Set default values for AdminReply or handle the fallback logic here
		return defaultAdminReply;
	}
}
