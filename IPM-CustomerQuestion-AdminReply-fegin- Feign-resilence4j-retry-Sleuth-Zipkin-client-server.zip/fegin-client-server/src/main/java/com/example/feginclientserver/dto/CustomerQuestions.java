package com.example.feginclientserver.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerQuestions {

	private Long qid;

	private String customeremail;

	private String qtopic;
  
	private String qdetails;

	private String qdate;

	@Override
	public String toString() {
		return "CustomerQuestions [qid=" + qid + ", customeremail=" + customeremail + ", qtopic=" + qtopic
				+ ", qdetails=" + qdetails + ", qdate=" + qdate + "]";
	}

}
