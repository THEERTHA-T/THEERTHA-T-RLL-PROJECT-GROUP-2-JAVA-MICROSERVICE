package com.example.feginclientserver.service.impl;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.example.feginclientserver.adminreply.AdminReplyFeginClient;
import com.example.feginclientserver.customerquestions.CustomerQuestionsFeginClient;
import com.example.feginclientserver.dto.AdminReply;
import com.example.feginclientserver.dto.AnswerResponse;
import com.example.feginclientserver.dto.CustomerQuestions;
import com.example.feginclientserver.service.CustomerQuestionsService;

@Service
public class CustomerQuestionsServiceImpl implements CustomerQuestionsService {

	@Autowired
	AdminReplyFeginClient adminReplyFeginClient;

	@Autowired
	CustomerQuestionsFeginClient customerQuestionsFeginClient;

	@Override
	public AnswerResponse getAnswerForQid(Long qId) {
		AnswerResponse answerResponse = new AnswerResponse();
		Optional<CustomerQuestions> customerQuestionsById = customerQuestionsFeginClient.getCustomerQuestionsById(qId);
		CustomerQuestions customerQuestions = new CustomerQuestions();
		if (customerQuestionsById.isPresent()) {
			customerQuestions = customerQuestionsById.get();
			answerResponse.setQId(customerQuestions.getQid());
			;
			answerResponse.setQuestionDetails(customerQuestions.getQdetails());
			;
			answerResponse.setQuestionTopic(customerQuestions.getQtopic());
			answerResponse.setQuestionDate(customerQuestions.getQdate());
			AdminReply adminReply = adminReplyFeginClient.getAdminReplyById(qId);
			if (adminReply == null) {
				answerResponse.setErrorMessage(answerResponse.getErrorMessage() + " : No Answer found for " + qId);
			} else {
				answerResponse.setAnswer(adminReply.getQanswer());
				answerResponse.setAnswerDate(adminReply.getQanswerdate());
			}
		} else {
			answerResponse.setErrorMessage("No Question found for " + qId);
		}

		return answerResponse;
	}

	@Override
	public List<AnswerResponse> getAllQuestions() {
		List<AnswerResponse> answerResponses = new ArrayList<AnswerResponse>();
		List<CustomerQuestions> customerQuestions = customerQuestionsFeginClient.getAllCustomerQuestions();
		for (CustomerQuestions customerQuestion : customerQuestions) {
			answerResponses.add(getAnswerForQid(customerQuestion.getQid()));
		}
		return answerResponses;
	}

	@Override
	public List<CustomerQuestions> getAllQuestionsAdmin() {
		return customerQuestionsFeginClient.getAllCustomerQuestions();
	}

	@Override
	public String saveQuestion(CustomerQuestions cq) {
		HttpStatus statueHttpStatus = customerQuestionsFeginClient.createNewCustomerQuestion(cq);
		
		if(HttpStatus.GATEWAY_TIMEOUT.equals(statueHttpStatus)) {
			return "Question saved successfully from fallback method";			
		}else {
			return "Question saved successfully";
		}

	}

	@Override
	public String saveAnswer(AdminReply adminReply) {
		HttpStatus statueHttpStatus = adminReplyFeginClient.saveAdminReply(adminReply);
		if(HttpStatus.GATEWAY_TIMEOUT.equals(statueHttpStatus)) {
			return "Answer saved successfully from fallback method";			
		}else {
			return "Answer saved successfully";
		}
		
	}

}
