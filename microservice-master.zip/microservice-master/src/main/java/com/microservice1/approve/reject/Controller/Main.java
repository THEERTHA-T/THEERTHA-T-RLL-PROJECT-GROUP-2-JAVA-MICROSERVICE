package com.microservice1.approve.reject.Controller;

import com.microservice1.approve.reject.ProjectExecption;
import com.microservice1.approve.reject.Model.CustomerApplyPolicy;
import com.microservice1.approve.reject.Services.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
public class Main {
  @Autowired
  Service service;
  
  
  
  
  @GetMapping("/getallaplicationofpolicy")

	public List<CustomerApplyPolicy> showApplication() {

		return service.getCustomerApplication();
	}
  
  @PutMapping("/updatestatus/{id}")

	public String updateStatus(@PathVariable Long id, @RequestBody CustomerApplyPolicy cap) {

		CustomerApplyPolicy cp = service.updateStatus(id, cap);
		if (cp != null) {

			service.updateStatus(id, cap);

			return "Updated";
		} else {
			throw new ProjectExecption();
		}

	}@GetMapping("/countApprove")
	public int countApprove() {

		return service.countOfApprove("Approved");
	}

	// count pending
	@GetMapping("/countPending")
	public int countPending() {

		return service.countOfApprove("Pending");
	}

	@GetMapping("/countrejected")
	public int countRejacted() {
		return service.countOfApprove("Rejected");
	}

	@GetMapping("/countapplication")
	public int countApply() {
		List<CustomerApplyPolicy> capp = service.getCustomerApplication();
		return capp.size();
	}
	@DeleteMapping("/deleteaplication/{id}")

	public HttpStatus deleteStatus(@PathVariable("id") Long id) {

		service.deleteCustomerApplication(id);

		return HttpStatus.OK;

	}

}
