package com.microservice1.approve.reject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import com.microservice1.approve.reject.Model.CustomerApplyPolicy;
import com.microservice1.approve.reject.Repositeries.Repository;

@EnableDiscoveryClient
@SpringBootApplication
public class Application implements CommandLineRunner {

  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }

  @Autowired
  private Repository customerApplyPolicyRepo;
  
    @Override
    public void run(String... args) throws Exception {
    	   customerApplyPolicyRepo.save(new CustomerApplyPolicy(null, "user1", "user1@gmail.com", "600000", "Health Insurance", "health", "Pending", TodaysDate.todayDate()));
           customerApplyPolicyRepo.save(new CustomerApplyPolicy(null, "user2", "user1@gmail.com", "600000", "Health Insurance", "health", "Pending", TodaysDate.todayDate()));
           customerApplyPolicyRepo.save(new CustomerApplyPolicy(null, "user2", "user1@gmail.com", "600000", "Health Insurance", "health", "Success", TodaysDate.todayDate()));

    }
	

  
  
}
