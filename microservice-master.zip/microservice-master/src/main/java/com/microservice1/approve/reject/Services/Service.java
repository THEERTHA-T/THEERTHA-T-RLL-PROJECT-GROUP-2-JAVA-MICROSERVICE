package com.microservice1.approve.reject.Services;

import com.microservice1.approve.reject.Model.CustomerApplyPolicy;
import com.microservice1.approve.reject.Repositeries.Repository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ResponseBody;

@org.springframework.stereotype.Service
public class Service {
  @Autowired
  Repository repository;
//Aplly Policy or Save Policy in Apply Table
	public CustomerApplyPolicy applicatonPolicy(CustomerApplyPolicy apply) {
		return repository.save(apply);
	}

	// Getting Apllication Table
	public List<CustomerApplyPolicy> getCustomerApplication() {

		return repository.findAll();

	}
	// Update Status
	public CustomerApplyPolicy updateStatus(Long id, CustomerApplyPolicy application) {
		CustomerApplyPolicy cp = repository.findByAppid(id);
		if (cp != null) {
			cp.setStatus(application.getStatus());
			return repository.save(cp);
		} else {
			return null;
		}

	}

	// Delete Customer Application
	public void deleteCustomerApplication(Long id) {

		this.repository.deleteById(id);
	}



	// Counting which one approve or disapprove
	public int countOfApprove(String status) {

		List<CustomerApplyPolicy> approve_list = repository.findByStatusIs(status);

		return approve_list.size();

	}



	public List<CustomerApplyPolicy> showDataStatus(String status) {

		List<CustomerApplyPolicy> data_status = repository.findByStatusIs(status);

		return data_status;

	}


}
