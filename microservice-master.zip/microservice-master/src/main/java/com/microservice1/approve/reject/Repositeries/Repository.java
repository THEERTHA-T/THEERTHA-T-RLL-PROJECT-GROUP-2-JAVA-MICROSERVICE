package com.microservice1.approve.reject.Repositeries;

import com.microservice1.approve.reject.Model.CustomerApplyPolicy;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

@org.springframework.stereotype.Repository
public interface Repository extends JpaRepository<CustomerApplyPolicy, Long> {
	
	
	public CustomerApplyPolicy findByAppid(Long id);

    public	List<CustomerApplyPolicy> findByStatusIs(String status);
    
    	public List<CustomerApplyPolicy> findBycustomeremailIs(String customeremail);
}
