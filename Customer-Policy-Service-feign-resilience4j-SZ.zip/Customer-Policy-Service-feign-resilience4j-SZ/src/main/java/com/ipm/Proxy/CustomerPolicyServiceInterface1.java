package com.ipm.Proxy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ipm.entity.CustomerApplyPolicy;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;


@FeignClient("CUSTOMER-POLICY-SERVICE1")
public interface CustomerPolicyServiceInterface1 {

	@Retry(name = "CUSTOMER-POLICY-SERVICE1")
	@CircuitBreaker(name = "CUSTOMER-POLICY-SERVICE1", fallbackMethod = "fallbackMethodApplyPolicy")
	 @PostMapping("/applyforpolicy")
	public CustomerApplyPolicy ApplyPolicy(CustomerApplyPolicy policies);
		

	@Retry(name = "CUSTOMER-POLICY-SERVICE1")
	@CircuitBreaker(name = "CUSTOMER-POLICY-SERVICE1", fallbackMethod = "fallbackMethodHistoryApplication")
	@GetMapping("/historyofapplications/{cemail}")
	public List<CustomerApplyPolicy> history(@PathVariable("cemail") String cemail);
	
	
	 @Retry(name = "CUSTOMER-POLICY-SERVICE1")
	    @CircuitBreaker(name = "CUSTOMER-POLICY-SERVICE1", fallbackMethod = "fallbackMethodRejectedApplication")
	    @GetMapping("/getcustomersByRejected")
	    public List<CustomerApplyPolicy> getRejectedPolicies(@RequestParam("status") String status);

	    @Retry(name = "CUSTOMER-POLICY-SERVICE1")
	    @CircuitBreaker(name = "CUSTOMER-POLICY-SERVICE1", fallbackMethod = "fallbackMethodPendingApplication")
	    @GetMapping("/getcustomersByPending")
	    public List<CustomerApplyPolicy> getPendingPolicies(@RequestParam("status") String status);

	    @Retry(name = "CUSTOMER-POLICY-SERVICE1")
	    @CircuitBreaker(name = "CUSTOMER-POLICY-SERVICE1", fallbackMethod = "fallbackMethodApprovedApplication")
	    @GetMapping("/getcustomersByApproved")
	    public List<CustomerApplyPolicy> getApprovedPolicies(@RequestParam("status") String status);

	    // ...

	    default List<CustomerApplyPolicy> fallbackMethodRejectedApplication(String status,Throwable throwable) {
	        System.err.println("Fallback: Request to List Rejected Policies is failed.");
	        return Collections.emptyList();
	    }

	    default List<CustomerApplyPolicy> fallbackMethodPendingApplication(String status,Throwable throwable) {
	        System.err.println("Fallback: Request to List Pending Policies is failed.");
	        return Collections.emptyList();
	    }

	    default List<CustomerApplyPolicy> fallbackMethodApprovedApplication(String status,Throwable throwable) {
	        System.err.println("Fallback: Request to List Approved Policies is failed.");
	        return Collections.emptyList();
	    }

	

	default CustomerApplyPolicy fallbackMethodApplyPolicy(CustomerApplyPolicy policies,Throwable throwable)
	{
 		System.err.println("Fallback : Request to Apply Policy  is failed.");
 	    throwable.printStackTrace(); // Log the exception for debugging

 		return new CustomerApplyPolicy();
	}

	default List<CustomerApplyPolicy> fallbackMethodHistoryApplication(String cemail,Throwable throwable)
	{
 		System.err.println("Fallback : Request to History Policy  is failed.");
 	    return Collections.emptyList(); // Or any other suitable default value

	}

	

}
