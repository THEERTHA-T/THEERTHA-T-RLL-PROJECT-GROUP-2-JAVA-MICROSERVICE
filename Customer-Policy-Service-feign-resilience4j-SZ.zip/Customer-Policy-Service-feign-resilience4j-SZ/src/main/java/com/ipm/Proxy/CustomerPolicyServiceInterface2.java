package com.ipm.Proxy;



import java.util.Collections;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.ipm.entity.CustomerApplyPolicy;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("CUSTOMER-POLICY-SERVICE2")
public interface CustomerPolicyServiceInterface2 {
	
	@Retry(name = "CUSTOMER-POLICY-SERVICE2")
	@CircuitBreaker(name = "CUSTOMER-POLICY-SERVICE2", fallbackMethod = "getallaplicationofpolicy")
	 @GetMapping("/getallaplicationofpolicy")
    List<CustomerApplyPolicy> getCustomerApplication();
	
	@Retry(name = "CUSTOMER-POLICY-SERVICE2")
	@CircuitBreaker(name = "CUSTOMER-POLICY-SERVICE2", fallbackMethod = "updatestatus")
	 @PutMapping("/updatestatus/{id}")
	String updateStatus(@PathVariable("id") Long id, @RequestBody  CustomerApplyPolicy cap);

	
	@Retry(name = "CUSTOMER-POLICY-SERVICE2")
	@CircuitBreaker(name = "CUSTOMER-POLICY-SERVICE2", fallbackMethod = "countApprove")
	@GetMapping("/countApprove")
    int countOfApprove(@RequestParam("status") String status);
	
	
	@Retry(name = "CUSTOMER-POLICY-SERVICE2")
	@CircuitBreaker(name = "CUSTOMER-POLICY-SERVICE2", fallbackMethod = "countPending")
	  @GetMapping("/countPending")
    int countOfPending(@RequestParam("status") String status);
	
	
	@Retry(name = "CUSTOMER-POLICY-SERVICE2")
	@CircuitBreaker(name = "CUSTOMER-POLICY-SERVICE2", fallbackMethod = "countrejected")
	 @GetMapping("/countrejected")
    int countOfRejected(@RequestParam("status") String status);
	
	@Retry(name = "CUSTOMER-POLICY-SERVICE2")
	@CircuitBreaker(name = "CUSTOMER-POLICY-SERVICE2", fallbackMethod = "deleteaplication")
	@DeleteMapping("/deleteaplication/{id}")
    void deleteCustomerApplication(@PathVariable("id") Long id);
	
	default List<CustomerApplyPolicy> getallaplicationofpolicy(Throwable throwable) {
        // Fallback for getCustomerApplication()
        System.err.println("Fallback: Unable to fetch customer applications.");
        return Collections.emptyList();
    }
	
	default String updatestatus(Long id, CustomerApplyPolicy cap,Throwable throwable) {
        // Fallback for updateStatus()
 	    throwable.printStackTrace(); // Log the exception for debugging

        System.err.println("Fallback: Unable to update status for customer application with ID " + id);
        return "fallback update"; // You can return a default object or handle the fallback accordingly.
    }

    
	default int countApprove(String status,Throwable throwable) {
        // Fallback for countOfApprove()
        System.err.println("Fallback: Unable to count approved applications.");
        return 0; // Or any other suitable default value.
    }

	default int countPending(String status,Throwable throwable) {
        // Fallback for countOfPending()
        System.err.println("Fallback: Unable to count pending applications.");
        return 0; // Or any other suitable default value.
    }

	default int countrejected(String status,Throwable throwable) {
        // Fallback for countOfRejected()
        System.err.println("Fallback: Unable to count rejected applications.");
        return 0; // Or any other suitable default value.
    }

	default void deleteaplication(Long id,Throwable throwable) {
        // Fallback for deleteCustomerApplication()
        System.err.println("Fallback: Unable to delete customer application with ID " + id);
    }
	

}
