package com.ipm.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipm.Exception.ProjectException;
import com.ipm.Proxy.CustomerPolicyServiceInterface1;
import com.ipm.Proxy.CustomerPolicyServiceInterface2;
import com.ipm.entity.CustomerApplyPolicy;


@RestController
@Scope("request")
@RequestMapping("/demo")
public class CustomerClientController {

	HttpStatus hs;

	@Autowired
	private CustomerPolicyServiceInterface1 customerServiceInterface1;

	@Autowired
	private CustomerPolicyServiceInterface2 customerServiceInterface2;
	
    private Logger log = LoggerFactory.getLogger(CustomerClientController.class);

    @PostMapping("/applyforpolicy")
	public CustomerApplyPolicy ApplyPolicy(@RequestBody CustomerApplyPolicy policies) {
        log.debug("------creating a Apply Policy Application request------");

    	return customerServiceInterface1.ApplyPolicy(policies);
	}

	@GetMapping("/historyofapplications/{cemail}")
	public List<CustomerApplyPolicy> history(@PathVariable("cemail") String cemail) {
        log.debug("------creating a History of  Policy request------");

		return customerServiceInterface1.history(cemail);
	}

	

	//harsh
	@GetMapping("/getcustomersByRejected")
	public List<CustomerApplyPolicy> getCustomerApplications() {
        log.debug("------creating a Rejected Policy request------");

		return customerServiceInterface1.getRejectedPolicies("Rejected");

	}

	//harsh
	@GetMapping("/getcustomersByPending")

	public List<CustomerApplyPolicy> getCustomerByPending() {
        log.debug("------creating a Pending Policy request------");

		return customerServiceInterface1.getPendingPolicies("Pending");

	}

	//harsh
	@GetMapping("/getcustomersByApproved")
	public List<CustomerApplyPolicy> getCustomerByApproved() {
        log.debug("------creating a Approved Policy request------");

		return customerServiceInterface1.getApprovedPolicies("Approved");

	}

	  
	  @GetMapping("/getallaplicationofpolicy")

		public List<CustomerApplyPolicy> showApplication() {
	        log.debug("------creating a get all Policy request------");

			return customerServiceInterface2.getCustomerApplication();
		}
	  
	  @PutMapping("/updatestatus/{id}")

		public String updateStatus(@PathVariable Long id, @RequestBody CustomerApplyPolicy cap) {

			
		        log.debug("------creating a update status Policy request------");

				customerServiceInterface2.updateStatus(id,cap);

				return "Updated";
			
		}@GetMapping("/countApprove")
		public int countApprove() {
	        log.debug("------creating a count Approved Policy request------");

			return customerServiceInterface2.countOfApprove("Approved");
		}

		// count pending
		//ashish
		@GetMapping("/countPending")
		public int countPending() {
	        log.debug("------creating a count pending Policy request------");

			return customerServiceInterface2.countOfApprove("Pending");
		}

		//ashish
		@GetMapping("/countrejected")
		public int countRejacted() {
	        log.debug("------creating a count rejected Policy request------");

			return customerServiceInterface2.countOfApprove("Rejected");
		}

		//ashish
		@GetMapping("/countapplication")
		public int countApply() {
	        log.debug("------creating a count total Policy request------");

			List<CustomerApplyPolicy> capp = customerServiceInterface2.getCustomerApplication();
			return capp.size();
		}
		@DeleteMapping("/deleteaplication/{id}")

		public HttpStatus deleteStatus(@PathVariable("id") Long id) {
	        log.debug("------creating a delete Policy request------");

			customerServiceInterface2.deleteCustomerApplication(id);

			return HttpStatus.OK;

		}
}
