package com.example.feginclientserver.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor

public class AdminReply {
	
	private Long answerid;
	private String qanswer;
	private long qid;
	private String qanswerdate;

}
