package com.example.feginclientserver.dto;

import lombok.Data;

@Data
public class AnswerResponse {

	long qId;
	String questionDetails;
	String questionTopic;
	String answer;
	String questionDate;
	String answerDate;
	String errorMessage =" ";
	
	
}
