package com.example.feginclientserver.customerquestions;



import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.feginclientserver.dto.CustomerQuestions;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("CUSTOMER-QUESTION")
public interface CustomerQuestionsFeginClient {


	@Retry(name = "CUSTOMER-QUESTION")
	@CircuitBreaker(name = "CUSTOMER-QUESTION",fallbackMethod = "fallBackMethodCreateNewCustomerQuestion")
	@PostMapping("save")
	public HttpStatus createNewCustomerQuestion(@RequestBody CustomerQuestions customerQuestions);
	
	@Retry(name = "CUSTOMER-QUESTION")
    @CircuitBreaker(name = "CUSTOMER-QUESTION", fallbackMethod = "fallbackMethodGetAllCustomers")
	@GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<CustomerQuestions> getAllCustomerQuestions();

	
	
	@Retry(name = "CUSTOMER-QUESTION")
    @CircuitBreaker(name = "CUSTOMER-QUESTION", fallbackMethod = "fallbackMethodGetCustomerQuestionById")
	@GetMapping(value = "/{qid}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Optional<CustomerQuestions> getCustomerQuestionsById(@PathVariable("qid") Long qid);

	
	@Retry(name = "CUSTOMER-QUESTION")
    @CircuitBreaker(name = "CUSTOMER-QUESTION", fallbackMethod = "fallbackMethodGetCustomerQuestionByEmail")
	@GetMapping("/customeremail/{email}")
	public List<CustomerQuestions> findCustomerQuestionsByEmail(@PathVariable("email") String email);

	
	@Retry(name = "CUSTOMER-QUESTION")
    @CircuitBreaker(name = "CUSTOMER-QUESTION", fallbackMethod = "fallbackMethodGetCountCustomerQuestions")
	@GetMapping("/count")
	public int countCustomerQuestions();
	
	
		
	default HttpStatus fallBackMethodCreateNewCustomerQuestion(@RequestBody CustomerQuestions customerQuestions ,Throwable throwable) {
		System.err.println("in fallback methos for create  new customer question ");
		return HttpStatus.GATEWAY_TIMEOUT;
	}
	
	default List<CustomerQuestions> fallbackMethodGetAllCustomers(Throwable throwable) {
        System.err.println("Fallback: Request to getAllCustomerQuestions is failed.");
        
        List<CustomerQuestions>  fallbackList = new ArrayList();
        CustomerQuestions customerQuestions = new CustomerQuestions();
        customerQuestions.setCustomeremail("Fallback Email");
        customerQuestions.setQdate("Fallback Date");
        customerQuestions.setQdetails("Fallback detail");
        customerQuestions.setQtopic("fallback topic");
        fallbackList.add(customerQuestions);
        // Add default AdminReply or handle the fallback logic here
        return fallbackList;
    }
	
	default List<CustomerQuestions> fallbackMethodGetCustomerQuestionByEmail(Throwable throwable) {
        System.err.println("Fallback: Request to get customer questions by email  is failed.");
        List<CustomerQuestions> fallbackList =  new ArrayList<CustomerQuestions>();
        CustomerQuestions customerQuestions = new CustomerQuestions();
        customerQuestions.setCustomeremail("Fallback Email");
        customerQuestions.setQdate("Fallback Date");
        customerQuestions.setQdetails("Fallback detail");
        customerQuestions.setQtopic("fallback topic");
        fallbackList.add(customerQuestions);
        return fallbackList;
    }
	
	default Optional<CustomerQuestions> fallbackMethodGetCustomerQuestionById(Throwable throwable) {
        System.err.println("Fallback: Request to getCustomerQuestionby question id is failed.");
        CustomerQuestions customerQuestions = new CustomerQuestions();
        customerQuestions.setCustomeremail("Fallback Email");
        customerQuestions.setQdate("Fallback Date");
        customerQuestions.setQdetails("Fallback detail");
        customerQuestions.setQtopic("fallback topic");
        customerQuestions.setQid(0L);
        Optional<CustomerQuestions> fallbackList = Optional.of(customerQuestions);
        // Add default AdminReply or handle the fallback logic here
        return fallbackList;
    }
	
	default int fallbackMethodGetCountCustomerQuestions(Throwable throwable) {
        System.err.println("Fallback: Request to get count of questionsa is failed.");
        int count = 0;
        // Add default AdminReply or handle the fallback logic here
        return count;
    }

	
	
	
	
}
