package com.example.feginclientserver;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Admin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.feginclientserver.adminreply.AdminReplyFeginClient;
import com.example.feginclientserver.dto.AdminReply;

@RestController
public class FeginController {

	@Autowired
	FeginStudentClient client;
	
	@Autowired
	AdminReplyFeginClient adminReplyFeginClient;
	
	@GetMapping("feginHello")
	public String helloFun() {
		return client.sayHello();
	}
	
	@GetMapping("answer/{qId}")
	public AdminReply getAnswerForQid(@PathVariable("qId") Long qId) {
		return adminReplyFeginClient.getAdminReplyById(qId);
	}
}
