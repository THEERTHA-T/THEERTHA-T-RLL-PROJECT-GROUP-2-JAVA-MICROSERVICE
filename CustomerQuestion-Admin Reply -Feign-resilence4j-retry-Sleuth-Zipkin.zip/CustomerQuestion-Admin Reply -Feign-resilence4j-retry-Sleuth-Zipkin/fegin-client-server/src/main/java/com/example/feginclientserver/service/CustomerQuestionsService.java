package com.example.feginclientserver.service;

import java.util.List;

import com.example.feginclientserver.dto.AdminReply;
import com.example.feginclientserver.dto.AnswerResponse;
import com.example.feginclientserver.dto.CustomerQuestions;

public interface CustomerQuestionsService {

	AnswerResponse getAnswerForQid(Long qId);

	List<AnswerResponse> getAllQuestions();

	List<CustomerQuestions> getAllQuestionsAdmin();

	String saveQuestion(CustomerQuestions cq);

	String saveAnswer(AdminReply adminReply);
	
	

}
