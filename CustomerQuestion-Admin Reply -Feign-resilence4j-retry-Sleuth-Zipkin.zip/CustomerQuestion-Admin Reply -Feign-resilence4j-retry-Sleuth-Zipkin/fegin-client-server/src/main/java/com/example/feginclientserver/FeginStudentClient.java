package com.example.feginclientserver;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "STUDENT-SERVICE")
public interface FeginStudentClient {
	
	@GetMapping("student/hello")
	public String sayHello();

	
}
