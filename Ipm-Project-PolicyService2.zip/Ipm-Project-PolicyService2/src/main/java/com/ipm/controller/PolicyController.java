package com.ipm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipm.Exception.ProjectException;
import com.ipm.entity.Policy;
import com.ipm.services.PolicyService;

@RestController
@CrossOrigin("http://localhost:4200")

public class PolicyController {
	@Autowired
	@Qualifier("policyService")

	PolicyService ps;
	HttpStatus hs;

	// Save Policys
	

	// get policy
	@GetMapping("/getpolicys")
	public List<Policy> getPolicy() {
		return ps.showPolicy();

	}

	
	
	// Update Policy by id
	@PutMapping("/updatepolicy/{id}")
	public HttpStatus updatePolicy(@PathVariable("id") Long id, @RequestBody Policy p) {
		Policy pp = ps.updatePolicyById(id, p);
		if (pp != null) {
			return HttpStatus.OK;
		} else {
			throw new ProjectException();
		}
	}

	@DeleteMapping("/deletepolicy/{id}")
	public HttpStatus deletePolicyById(@PathVariable Long id) {
		try {
			ps.deletebyid(id);
			return HttpStatus.OK;
		} catch (Exception e) {

			throw new ProjectException();
		}
	}

	
}
