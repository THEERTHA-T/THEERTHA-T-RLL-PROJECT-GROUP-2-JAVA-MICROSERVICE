package com.ipm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ipm.Exception.ProjectException;
import com.ipm.entity.Customer;
import com.ipm.services.CustomerService;

@RestController
@CrossOrigin("http://localhost:4200")

public class CustomerController {
	@Autowired
	CustomerService customerService;
	HttpStatus hs;

	@PutMapping("/updatecustomer/{email}")
	public String updateCustomer(@PathVariable("email") String email, @RequestBody Customer customer) {
		try {

			Customer cc = customerService.updateCustomerByEmail(email, customer);
			if (cc != null) {
				return customer.getCname() + " Your data is updated";
			} else {

				throw new ProjectException();
			}

		} catch (Exception e) {
			throw new ProjectException();
		}

	}

	@DeleteMapping("/deletecustomer/{id}")
	public String deleteUser(@PathVariable("id") Long id) {
		try {
			customerService.deletecustomer(id);
			return id + "  this Id of Customer Deleted";
		} catch (Exception e) {
			throw new ProjectException("Your  " + id + " Not foud");

		}
	}

}
