package com.ipm.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ipm.TodaysDate;
import com.ipm.Exception.ProjectException;
import com.ipm.entity.Customer;
import com.ipm.repository.CustomerRepository;

@Service(value = "customerService")
@Scope("singleton")
@Transactional
public class CustomerService {
	@Autowired
	CustomerRepository crepo;

	public Customer updateCustomerByEmail(String email, Customer customer)  {
		Customer cc = crepo.findByCemail(email);

		if (cc != null) {

			cc.setCname(customer.getCname());
			cc.setCpassword(customer.getCpassword());
			cc.setCgender(customer.getCgender());
			cc.setCphno(customer.getCphno());
			cc.setCaddress(customer.getCaddress());
			cc.setCemail(customer.getCemail());
			cc.setCage(customer.getCage());

			return crepo.save(cc);
		} else {
			return null;
		}
	}

	public void deletecustomer(Long id) {
		crepo.deleteById(id);
	}

}
