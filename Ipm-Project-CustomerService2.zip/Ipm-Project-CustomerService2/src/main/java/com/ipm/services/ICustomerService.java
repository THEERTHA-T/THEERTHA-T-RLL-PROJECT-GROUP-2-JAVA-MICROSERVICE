package com.ipm.services;

import java.util.List;

import com.ipm.Exception.ProjectException;
import com.ipm.entity.Customer;

public interface ICustomerService {
	
	public Customer updateCustomerByEmail(String email, Customer customer);
	public void deletecustomer(Long id);

		
	}



